package assignment_First;

import java.rmi.Naming;
import java.rmi.RemoteException;

public class Client {
    public final static int amount = 10;

    public static void main(String[] args) {
        try {
            BankAccount bankAccount = (BankAccount) Naming.lookup("rmi://localhost/BankAccount");
            System.out.println("Current amount in the bank account: " + bankAccount.getBalance());
            System.out.println("Deposit: " + amount);
            bankAccount.deposit(amount);
            System.out.println("Amount after deposit: " + bankAccount.getBalance());
            System.out.println("Withdraw: " + amount);
            bankAccount.withdraw(amount);
            System.out.println("Amount after withdraw: " + bankAccount.getBalance());
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
