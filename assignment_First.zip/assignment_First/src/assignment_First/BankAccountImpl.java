package assignment_First;

import java.rmi.RemoteException;

public class BankAccountImpl implements BankAccount {
    private double amount = 50;

    @Override
    public synchronized void deposit(int amount) throws RemoteException {
        this.amount += amount;
    }

    @Override
    public synchronized void withdraw(int amount) throws RemoteException {
        this.amount -= amount;
    }

    @Override
    public synchronized double getBalance() throws RemoteException {
        return amount;
    }
}
