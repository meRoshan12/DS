/**
 * 
 */
/**
 * @author rosha
 *
 */
//module assignment_First {
//	requires java.rmi;
//}

module assignment_First {
    exports assignment_First;
    requires java.rmi;
}
